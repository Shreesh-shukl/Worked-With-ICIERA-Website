<!DOCTYPE html>
<html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  
  <title>ICIERA 21 - International Conference on Industrial Electronics Research and Applications, 2021</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="https://ece.mait.ac.in/templates/purity_iii/favicon.ico" rel="icon">
  <!--<link href="img/apple-touch-icon.png" rel="apple-touch-icon">-->

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800"
    rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/venobox/venobox.css" rel="stylesheet">
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">
  <style>
      .w700{
          font-weight:700;
      }
      table p{
          margin-bottom:0px !important;
      }
  </style>
</head>

<body>

  <!--==========================
    Header
  ============================-->
  <header id="header">
    <div class="container">

      <div id="logo" class="pull-left">
        <!-- Uncomment below if you prefer to use a text logo -->
        <h1><a href="#main">IC<span>IERA</span> 20<span>21</span></a></h1>
        <!--<a href="#intro" class="scrollto"><img src="img/logo.png" alt="" title=""></a>-->
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="menu-active"><a href="#intro">Home</a></li>
          <li><a href="#about">About</a></li>
          <!--<li><a href="#speakers">Speakers</a></li>-->
          <li><a href="#tracks">Tracks</a></li>
          <li><a href="#schedule">Schedule</a></li>
          <li><a href="#venue">Venue</a></li>
          <!--<li><a href="#hotels">Hotels</a></li>
          <li><a href="#gallery">Gallery</a></li>-->
          <li><a href="#supporters">Sponsors</a></li>
          <!--<li><a href="#contact">Contact</a></li>
          <li class="buy-tickets"><a href="#buy-tickets">Buy Tickets</a></li>-->
        </ul>
      </nav><!-- #nav-menu-container -->
    </div>
  </header><!-- #header -->

  <!--==========================
    Intro Section
  ============================-->
  <section id="intro">
    <div class="intro-container wow fadeIn">
      <h1 class="mb-4 pb-0">International Conference on <br><span>Industrial Electronics <br>Research and Applications</span></h1>
      <p class="mb-2 pb-0">Organized By</p>
      <h3 class="mb-2 pb-0 text-theme">Department of Electronics and Communication Engineering</h3>
      <p class="mb-2 pb-0">Maharaja Agrasen Institute Of Technology</p>
      <p class="mb-2 pb-0">Rohini, Sec-22, New Delhi-110086, India</p>
      <!--<a href="https://www.youtube.com/watch?v=jDDaplaOz7Q" class="venobox play-btn mb-4" data-vbtype="video" data-autoplay="true"></a>-->
      <p class="mb-2 pb-0">Thursday to Saturday, 07th-09th October 2021</p>
      <a href="#about" class="about-btn scrollto">About The Event</a>
    </div>
  </section>

  <main id="main">

    <!--==========================
      About Section
    ============================-->
    <section id="about">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 text-justify">
            <h2>About The Event</h2>
            <p>ICIERA-21 is expected to provide a unique forum for researchers, enterprise-experts, engineers, academicians, scholars & scientists all over the world to interact on a common platform for 3-days in the premises of MAIT, Delhi in an event of its own kind.</p>
            <p>
                It will consist of keynotes, presentations, tutorials, workshops, and oral presentations on all aspects of state-of-the-art and innovative developments in the field of industrial electronics.
            </p>
          </div>
          <div class="col-lg-3">
            <h3>Where</h3>
            <p class="mb-2">Maharaja Agrasen Institute Of Technology</p>
            <p>Rohini, Sec-22, New Delhi-110086, India</p>
            <a href="#venue" class="about-btn scrollto">Explore</a>
          </div>
          <div class="col-lg-3">
            <h3>When</h3>
            <h5 class="text-white">Thursday to Saturday<br>07th-09th October 2021</h5>
            
            <a href="#schedule" class="about-btn scrollto">Schedule</a>
          </div>
        </div>
      </div>
    </section>
    <section class="py-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12 col-lg-10 text-justify">
                    <p>The aim of this conference is to showcase the latest technologies, strategies and challenges in the area of electrical & electronics for the enhancement of industrial processes, which will be achieved through the various activities listed above. 
                    </p>
                    <p>
                        The underlying theme of the proposed conference is “Smart Systems” and is intended to meet the needs of modern industry. It would be accomplished through the related tracks, as proposed. The organising team is open for suggestions and would continually be updating the proposed technical activities, as shall be decided by its highly qualified advisers and technical team members.
                    </p>
                </div>
            </div>
        </div>
    </section>
    
    <!--==========================
      Speakers Section
    ============================--
    <section id="speakers" class="wow fadeInUp">
      <div class="container">
        <div class="section-header">
          <h2>Event Speakers</h2>
          <p>Here are some of our speakers</p>
        </div>

        <div class="row">
          <div class="col-lg-4 col-md-6">
            <div class="speaker">
              <img src="img/speakers/1.jpg" alt="Speaker 1" class="img-fluid">
              <div class="details">
                <h3><a href="speaker-details.html">Brenden Legros</a></h3>
                <p>Quas alias incidunt</p>
                <div class="social">
                  <a href=""><i class="fa fa-twitter"></i></a>
                  <a href=""><i class="fa fa-facebook"></i></a>
                  <a href=""><i class="fa fa-google-plus"></i></a>
                  <a href=""><i class="fa fa-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="speaker">
              <img src="img/speakers/2.jpg" alt="Speaker 2" class="img-fluid">
              <div class="details">
                <h3><a href="speaker-details.html">Hubert Hirthe</a></h3>
                <p>Consequuntur odio aut</p>
                <div class="social">
                  <a href=""><i class="fa fa-twitter"></i></a>
                  <a href=""><i class="fa fa-facebook"></i></a>
                  <a href=""><i class="fa fa-google-plus"></i></a>
                  <a href=""><i class="fa fa-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="speaker">
              <img src="img/speakers/3.jpg" alt="Speaker 3" class="img-fluid">
              <div class="details">
                <h3><a href="speaker-details.html">Cole Emmerich</a></h3>
                <p>Fugiat laborum et</p>
                <div class="social">
                  <a href=""><i class="fa fa-twitter"></i></a>
                  <a href=""><i class="fa fa-facebook"></i></a>
                  <a href=""><i class="fa fa-google-plus"></i></a>
                  <a href=""><i class="fa fa-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="speaker">
              <img src="img/speakers/4.jpg" alt="Speaker 4" class="img-fluid">
              <div class="details">
                <h3><a href="speaker-details.html">Jack Christiansen</a></h3>
                <p>Debitis iure vero</p>
                <div class="social">
                  <a href=""><i class="fa fa-twitter"></i></a>
                  <a href=""><i class="fa fa-facebook"></i></a>
                  <a href=""><i class="fa fa-google-plus"></i></a>
                  <a href=""><i class="fa fa-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="speaker">
              <img src="img/speakers/5.jpg" alt="Speaker 5" class="img-fluid">
              <div class="details">
                <h3><a href="speaker-details.html">Alejandrin Littel</a></h3>
                <p>Qui molestiae natus</p>
                <div class="social">
                  <a href=""><i class="fa fa-twitter"></i></a>
                  <a href=""><i class="fa fa-facebook"></i></a>
                  <a href=""><i class="fa fa-google-plus"></i></a>
                  <a href=""><i class="fa fa-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="speaker">
              <img src="img/speakers/6.jpg" alt="Speaker 6" class="img-fluid">
              <div class="details">
                <h3><a href="speaker-details.html">Willow Trantow</a></h3>
                <p>Non autem dicta</p>
                <div class="social">
                  <a href=""><i class="fa fa-twitter"></i></a>
                  <a href=""><i class="fa fa-facebook"></i></a>
                  <a href=""><i class="fa fa-google-plus"></i></a>
                  <a href=""><i class="fa fa-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </section>



    <!--==========================
      Tracks Section
    ============================-->
    <section id="tracks" class="pt-5">
      <div class="container wow fadeInUp">
        <div class="section-header">
          <h2>Conference Tracks</h2>
        </div>
        <ul class="nav nav-tabs" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" href="#day-1" role="tab" data-toggle="tab">Track 01: Industrial Communications and Signal Processing</a>
          </li>
        </ul>
        <p class="text-justify">
          Communication Technologies for Industry 4.0; Green Communication in Industry; Energy- Efficient; Resource-Saving and Environment-Friendly Networking; Energy-Saving and Energy-Harvesting Networks; Green Design Networks; Self-Configurable Networks; Real-time in Industrial Communication Systems and Technologies; Wired and Wireless Industrial Networks; FSO; VLC; UWB; Antennas and Electromagnetic Fields; Industrial Ethernet Networks; Industrial Wireless Sensor Networks; Hybrid Wired/Wireless Industrial Networks; Time Sensitive Networks; Time Triggered Systems and Protocols; Hard and Soft Real-Time Message Scheduling; Networked Embedded Systems; Industrial Image Processing, Remote Sensing, Sensor Fusion, Industrial Internet of things (IIoT); Industrial Internet of Services (IIS), Smart Protocols,Signal Processing for Industrial Applications, Signal Processing for Smart Systems.
        </p>
        <ul class="nav nav-tabs" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" href="#day-1" role="tab" data-toggle="tab">Track 02: Industrial Electronics</a>
          </li>
        </ul>
        <p class="text-justify">
            Smart Materials (Piezoelectric, SMA, SMP, MSMA, ER/MR fluid, Optical Fibre, Polymer Gel etc.), Applications of Smart Structures, Microelectronic design, manufacturing, and integration, Smart sensors and instrumentation systems.
        </p>
        <ul class="nav nav-tabs" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" href="#day-1" role="tab" data-toggle="tab">Track 03: Industrial Sensors and Industrial Informatics</a>
          </li>
        </ul>
        <p class="text-justify">
          Smart Factories, Smart Manufacturing, Smart Sensors, Smart Tooling, Smart Measurement Techniques, Biological Inspired Sensors, Sensors for Autonomous vehicles/ Electric vehicles; Design and prototyping of smart sensors, Wireless Energy Transfer, Energy Harvesting Medical Devices; and any combination of above areas with emphasis on measurement with and without sensors will also be considered, RTOS Based Applications, Embedded System Security, Digital System Design and Structures, Industrial Artificial Intelligence (AI), Industrial Machine Learning (ML), Human-Machine Interactions, Diagnosis and Prognosis.
        </p>
        <ul class="nav nav-tabs" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" href="#day-1" role="tab" data-toggle="tab">Track 04: Industrial Control & Applications</a>
          </li>
        </ul>
        <p class="text-justify">
          Smart Manufacturing, Additive Manufacturing, Autonomous and Electric vehicles; Autonomous Agents; Cognitive Approach for Industrial Robotics; Collective and Social Robots; Control and Supervision in Industrial Systems; Engineering Applications on Robotics and Automation; Guidance, Navigation and Control in Smart Factories; Advance Automation and Control techniques related to Smart Industry and Smart Commercial Machines, Smart Robotics Science and Technology.
        </p>
        <ul class="nav nav-tabs" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" href="#day-1" role="tab" data-toggle="tab">Track 05: Power and energy systems (Special Focus on Smart Applications)</a>
          </li>
        </ul>
        <p class="text-justify">
            Power and Energy Systems for Smart Industry; New Energy Vehicles, Internet Energy Equipment; Green Building; Materials and Energy-saving Buildings; Renewable Energy Sources and Systems; Battery Technology – Materials and Systems; Other Energy Storage Systems; Micro-grid and Nano-grid; Energy management of Micro Grid; Building Energy Management, Signal Processing for the Smart Grid.
        </p>
        <ul class="nav nav-tabs" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" href="#day-1" role="tab" data-toggle="tab">Track 06: Invited and Special Tracks</a>
          </li>
        </ul>
        <p class="text-justify">
          The papers not aligning in the above tracks but found suitable and related to conference theme will be included in the special track.
        </p>
      </div>
    </section>


    <!--==========================
      Schedule Section
    ============================-->
    <section id="schedule" class="section-with-bg">
      <div class="container wow fadeInUp">
        <div class="section-header">
          <h2>Event Schedule</h2>
          <p>Brief program schedule. Detailed schedule will be updated soon.</p>
        </div>
        
        <ul class="nav nav-tabs" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" href="#day-1" role="tab" data-toggle="tab">Day 1: Oct 07</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#day-2" role="tab" data-toggle="tab">Day 2: Oct 08</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#day-3" role="tab" data-toggle="tab">Day 3: Oct 09</a>
          </li>
        </ul>
        <!--
        <h3 class="sub-heading">Voluptatem nulla veniam soluta et corrupti consequatur neque eveniet officia. Eius
          necessitatibus voluptatem quis labore perspiciatis quia.</h3>
        -->
        <div class="tab-content row justify-content-center">
            <div role="tabpanel" class="col-lg-9 tab-pane fade show active" id="day-1">
                <h4>Registration, Welcoming Speech, Keynote Speeches, Poster Presentations, Invited Speeches and Oral Presentations</h4>
            </div>
            <div role="tabpanel" class="col-lg-9 tab-pane fade" id="day-2">
                <h4>Invited Speeches, Oral Presentations and Workshop</h4>
            </div>
            <div role="tabpanel" class="col-lg-9 tab-pane fade" id="day-3">
                <h4>Oral Presentations and Valedictory</h4>
            </div>
          <!-- Schdule Day 1 ->
          <div role="tabpanel" class="col-lg-9 tab-pane fade show active" id="day-1">

            <div class="row schedule-item">
              <div class="col-md-2"><time>09:30 AM</time></div>
              <div class="col-md-10">
                <h4>Registration</h4>
                <p>Fugit voluptas iusto maiores temporibus autem numquam magnam.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>10:00 AM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/1.jpg" alt="Brenden Legros">
                </div>
                <h4>Keynote <span>Brenden Legros</span></h4>
                <p>Facere provident incidunt quos voluptas.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>11:00 AM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/2.jpg" alt="Hubert Hirthe">
                </div>
                <h4>Et voluptatem iusto dicta nobis. <span>Hubert Hirthe</span></h4>
                <p>Maiores dignissimos neque qui cum accusantium ut sit sint inventore.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>12:00 AM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/3.jpg" alt="Cole Emmerich">
                </div>
                <h4>Explicabo et rerum quis et ut ea. <span>Cole Emmerich</span></h4>
                <p>Veniam accusantium laborum nihil eos eaque accusantium aspernatur.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>02:00 PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/4.jpg" alt="Jack Christiansen">
                </div>
                <h4>Qui non qui vel amet culpa sequi. <span>Jack Christiansen</span></h4>
                <p>Nam ex distinctio voluptatem doloremque suscipit iusto.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>03:00 PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/5.jpg" alt="Alejandrin Littel">
                </div>
                <h4>Quos ratione neque expedita asperiores. <span>Alejandrin Littel</span></h4>
                <p>Eligendi quo eveniet est nobis et ad temporibus odio quo.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>04:00 PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/6.jpg" alt="Willow Trantow">
                </div>
                <h4>Quo qui praesentium nesciunt <span>Willow Trantow</span></h4>
                <p>Voluptatem et alias dolorum est aut sit enim neque veritatis.</p>
              </div>
            </div>

          </div>
          <!-- End Schdule Day 1 ->

          <!-- Schdule Day 2 ->
          <div role="tabpanel" class="col-lg-9  tab-pane fade" id="day-2">

            <div class="row schedule-item">
              <div class="col-md-2"><time>10:00 AM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/1.jpg" alt="Brenden Legros">
                </div>
                <h4>Libero corrupti explicabo itaque. <span>Brenden Legros</span></h4>
                <p>Facere provident incidunt quos voluptas.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>11:00 AM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/2.jpg" alt="Hubert Hirthe">
                </div>
                <h4>Et voluptatem iusto dicta nobis. <span>Hubert Hirthe</span></h4>
                <p>Maiores dignissimos neque qui cum accusantium ut sit sint inventore.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>12:00 AM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/3.jpg" alt="Cole Emmerich">
                </div>
                <h4>Explicabo et rerum quis et ut ea. <span>Cole Emmerich</span></h4>
                <p>Veniam accusantium laborum nihil eos eaque accusantium aspernatur.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>02:00 PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/4.jpg" alt="Jack Christiansen">
                </div>
                <h4>Qui non qui vel amet culpa sequi. <span>Jack Christiansen</span></h4>
                <p>Nam ex distinctio voluptatem doloremque suscipit iusto.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>03:00 PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/5.jpg" alt="Alejandrin Littel">
                </div>
                <h4>Quos ratione neque expedita asperiores. <span>Alejandrin Littel</span></h4>
                <p>Eligendi quo eveniet est nobis et ad temporibus odio quo.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>04:00 PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/6.jpg" alt="Willow Trantow">
                </div>
                <h4>Quo qui praesentium nesciunt <span>Willow Trantow</span></h4>
                <p>Voluptatem et alias dolorum est aut sit enim neque veritatis.</p>
              </div>
            </div>

          </div>
          <!-- End Schdule Day 2 ->

          <!-- Schdule Day 3 ->
          <div role="tabpanel" class="col-lg-9  tab-pane fade" id="day-3">

            <div class="row schedule-item">
              <div class="col-md-2"><time>10:00 AM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/2.jpg" alt="Hubert Hirthe">
                </div>
                <h4>Et voluptatem iusto dicta nobis. <span>Hubert Hirthe</span></h4>
                <p>Maiores dignissimos neque qui cum accusantium ut sit sint inventore.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>11:00 AM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/3.jpg" alt="Cole Emmerich">
                </div>
                <h4>Explicabo et rerum quis et ut ea. <span>Cole Emmerich</span></h4>
                <p>Veniam accusantium laborum nihil eos eaque accusantium aspernatur.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>12:00 AM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/1.jpg" alt="Brenden Legros">
                </div>
                <h4>Libero corrupti explicabo itaque. <span>Brenden Legros</span></h4>
                <p>Facere provident incidunt quos voluptas.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>02:00 PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/4.jpg" alt="Jack Christiansen">
                </div>
                <h4>Qui non qui vel amet culpa sequi. <span>Jack Christiansen</span></h4>
                <p>Nam ex distinctio voluptatem doloremque suscipit iusto.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>03:00 PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/5.jpg" alt="Alejandrin Littel">
                </div>
                <h4>Quos ratione neque expedita asperiores. <span>Alejandrin Littel</span></h4>
                <p>Eligendi quo eveniet est nobis et ad temporibus odio quo.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>04:00 PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/6.jpg" alt="Willow Trantow">
                </div>
                <h4>Quo qui praesentium nesciunt <span>Willow Trantow</span></h4>
                <p>Voluptatem et alias dolorum est aut sit enim neque veritatis.</p>
              </div>
            </div>

          </div>
          <!-- End Schdule Day 2 -->
        </div>
        
      </div>

    </section>

    <!--==========================
      Venue Section
    ============================-->
    <section id="venue" class="wow fadeInUp">

      <div class="container-fluid">

        <div class="section-header">
          <h2>Event Venue</h2>
          <p>Event venue location info and gallery</p>
        </div>

        <div class="row no-gutters">
          <div class="col-lg-6 venue-map">
            <iframe
              src="https://www.google.com/maps/embed/v1/place?q=maharaja+agrasen+institute+of+technology&key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8"
              frameborder="0" style="border:0" allowfullscreen></iframe>
          </div>

          <div class="col-lg-6 venue-info">
            <div class="row justify-content-center">
              <div class="col-11 col-lg-10">
                <h3>Maharaja Agrasen Institute Of Technology</h3>
                <p class="text-justify">Maharaja Agrasen Institute of Technology was established in 1999 by Maharaja Agrasen Technical Education Society promoted by a group of well known Industrialists, Businessman, Professionals and Philanthropists with an aim to promote quality education in the field of Technology and Management. Since then, MAIT has grown from strength to strength to emerge as one of the top technical institutes among the private Institutes and has been constantly ranked amongst the top engineering Institutes by DATAQUEST.</p>
              </div>
            </div>
          </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-12 col-lg-10 pt-5 text-justify">
                <p>The institute began its first batch of 180 B.Tech. students in 1999 and at present, MAIT offers Bachelor's Degree in 5 disciplines of Engineering - Computer Science and Engineering (240 students intake), Electronics and Communication Engineering, Electrical and Electronics Engineering, Information Technology, Mechanical and Automation Engineering (180 students intake each) and Mechanical Engineering (60 students intake) and Postgraduate degree in Master of Business Administration (180 students intake). The Institute is approved by All India Council for Technical Education and affiliated to Guru Gobind Singh Indraprastha University, Delhi.</p>
                <p>MAIT’s campus comprises of 10 blocks including Admin Block with Wi-Fi connectivity, well equipped modern laboratories, an intellectually stocked Learning Resource Centre with books and E-Resources, Boys Hostel, Gym and Auditorium.</p>
                <p>&nbsp;</p>
                <div class="section-header">
                  <h2>Department of Electronics and Communication Engineering</h2>
                </div>
                <p>Department of Electronics and Communication Engineering (NBA accredited) is running B.Tech. Programme in two Shifts. The department has published more than 653 peer reviewed research papers in international journals and more than 379 research articles are published in International/National conference. As per records, the h-index of the department is 26* and total citation is 2561* till date. The department has well established research labs mainly, Electronics lab, Advance Communication lab, Research lab, Fabrication lab, VLSI lab. The Faculty members have received R&D grants from funding agencies like UGC, DST, DBT, MNRE, AICTE etc. </p>
                <p>Department of Electronics and Communication Engineering, MAIT, New Delhi has rich background in terms of faculty in relevant areas and has international exposure. Faculty are publishing their research work in reputed IEEE journals and Transactions, Elsevier Journals, Springer and other journals of repute. The department has well established research facility in the area of Electronics, communication, devices, image processing etc. <!--Currently more than 05 funded research projects are running in the Department.--> The faculty have industry collaborations in research and experimental setups. The department is well connected with international research communities and industries.
                </p>
            </div>
        </div>
      </div>

      <!--<div class="container-fluid venue-gallery-container">
        <div class="row no-gutters">

          <div class="col-lg-3 col-md-4">
            <div class="venue-gallery">
              <a href="img/venue-gallery/1.jpg" class="venobox" data-gall="venue-gallery">
                <img src="img/venue-gallery/1.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="venue-gallery">
              <a href="img/venue-gallery/2.jpg" class="venobox" data-gall="venue-gallery">
                <img src="img/venue-gallery/2.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="venue-gallery">
              <a href="img/venue-gallery/3.jpg" class="venobox" data-gall="venue-gallery">
                <img src="img/venue-gallery/3.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="venue-gallery">
              <a href="img/venue-gallery/4.jpg" class="venobox" data-gall="venue-gallery">
                <img src="img/venue-gallery/4.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="venue-gallery">
              <a href="img/venue-gallery/5.jpg" class="venobox" data-gall="venue-gallery">
                <img src="img/venue-gallery/5.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="venue-gallery">
              <a href="img/venue-gallery/6.jpg" class="venobox" data-gall="venue-gallery">
                <img src="img/venue-gallery/6.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="venue-gallery">
              <a href="img/venue-gallery/7.jpg" class="venobox" data-gall="venue-gallery">
                <img src="img/venue-gallery/7.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div>

          <div class="col-lg-3 col-md-4">
            <div class="venue-gallery">
              <a href="img/venue-gallery/8.jpg" class="venobox" data-gall="venue-gallery">
                <img src="img/venue-gallery/8.jpg" alt="" class="img-fluid">
              </a>
            </div>
          </div>

        </div>
      </div>-->

    </section>
    <section id="committee" class="section-with-bg wow fadeInUp">

      <div class="container py-5">
        <div class="section-header">
          <h2>Committee Members</h2>
          <p>Name of the Organizers for ICIERA-2021</p>
        </div>
        <h4 class="w700 mb-1">Chief Patrons</h4>
        <h5 class="mb-1">Dr. N. K. Garg, Founder Chairman (MATES), Chancellor, MAU, Himachal Pradesh  </h5>
        <h5>Prof. Mahesh Verma, Vice-Chancellor, GGSIP University, New Delhi</h5>
        
        <h4 class="w700 mb-1"> Patrons</h4>
        <h5 class="mb-1">Prof. Yogesh Singh, Vice-Chancellor DTU, New Delhi </h5>
        <h5 class="mb-1">Prof. J.P. Saini, Vice-Chancellor NSUT, New Delhi </h5>
        <h5 class="mb-1">Prof. Bhim Singh, IIT Delhi, New Delhi </h5>
        <h5 class="mb-1">Prof. M. L. Goyal, Vice-Chairman, MAIT, New Delhi </h5>
        <h5>Prof. Neelam Sharma, Director, MAIT, New Delhi</h5>
        
        
        <!--<h4 class="w700 mb-1">Honorary Patrons</h4>
        <h5 class="mb-1">Prof. Yogesh Singh, Vice-Chancellor DTU, New Delhi</h5>
        <h5 class="mb-1">Prof. J.P Saini, Vice-Chancellor (NSUT), New Delhi</h5>
        <h5>Prof. Bhim Singh, IIT Delhi, New Delhi</h5>
        -->
        
        
        <!--
        <h4 class="w700 mb-1"> Honorary Chairs</h4>
        <h5 class="mb-1">Prof. Akshay Rathore, Concordia University, Canada</h5>
        <h5>Prof. S. K. Garg, Pro-VC, DTU, New Delhi</h5>
        -->
        <h4 class="w700 mb-1"> General Chairs</h4>
        <h5 class="mb-1">Prof. A. P. Mittal, NSUT, New Delhi</h5>
        <h5>Prof. Sunil Kumar, MAIT, New Delhi</h5>
        <h4 class="w700 mb-1"> Technical Chairs</h4>
        <h5 class="mb-1">Prof. Brejesh Lall, IIT Delhi, New Delhi</h5>
        <h5 class="mb-1">Prof. D.K. Jain, DCRUST, Murthal, Haryana</h5>
        <h5>Prof. Amit Prakash Singh, GGSIPU, Delhi</h5>
        <h4 class="w700 mb-1"> Publication Chair</h4>
        <h5>Prof. Ahteshamul Haque, Jamia Milia Islamia University, New Delhi</h5>
        
        <h4 class="w700 mb-1"> Program Chairs</h4>
        <h5 class="mb-1">Prof. Anubha Gupta, IIIT Delhi, New Delhi</h5>
        <h5>Prof. Alka Singh, DTU, New Delhi</h5>
        
        <h4 class="w700 mb-1"> Organizing Secretary</h4>
        <h5 class="mb-1">Dr. Nitin Sharma, MAIT, New Delhi</h5>
        <h5>Dr. Neelu Nagpal, MAIT, New Delhi</h5>
        
        <h4 class="w700 mb-1"> International Advisory Committee</h4>
        <h5 class="mb-1">Prof. Pierluigi Siano, University of Salerno, Italy</h5>
        <h5 class="mb-1">Prof. Fabio Caraffini, De Montfort University, UK</h5>
        <h5 class="mb-1">Prof. Akshay K Rathore, Concordia University, Canada</h5>
        <h5 class="mb-1">Prof. Szymanski Jerzy, Pulaski University of Technology and Humanities, Poland</h5>
        <h5 class="mb-1">Dr. Banmali Rawat, University of Nevada, Reno, USA</h5>
        <h5 class="mb-1">Dr. Osamah Ibrahim Khalaf, Baghdad, Iraq</h5>
        <h5 class="mb-1">Prof. Sheldon Williamson, Ontario Tech University, Canada</h5>
        <h5 class="mb-1">Prof. Anurag Srivastava, Washington State University, USA</h5>
        <h5 class="mb-1">Prof. Sanjeev Kumar Padmanban, Alborg University-Esbjerg Campus, Denmark</h5>
        <h5 class="mb-1">Dr. Md. Kamrul Alam Khan, Jagannath University, Bangladesh</h5>
        <h5>Ms. Geetika Chauhan, MicroEnergy International, Germany</h5>
        
        <h4 class="w700 mb-1"> Organizing Committee</h4>
        <h6>
            Dr. Javed Ahmed, MAIT, New Delhi<br>
            Dr. Parveen Sinha, MAIT, New Delhi<br>
            Dr. Sukhvinder Singh, MAIT, New Delhi<br>
            Dr. Divya Goel, MAIT, New Delhi<br>
            Mr. Rohit Rana, MAIT, New Delhi<br>
            More members are to be added
        </h6>
        
        <h4 class="w700 mb-1"> Technical Programme Committee</h4>
        <h6>
            Prof. G. Bhuveneshwari – IIT Delhi<br>
            Prof. Udayan Ghose, GGSIPU Delhi<br>
            Prof. S. P Singh, NSUT, New Delhi<br>
            Prof. Vijander Singh, NSUT, New Delhi<br>
            Prof. Harish Parthasrathy, NSUT, New Delhi<br>
            Prof. Rajeshwari Pandey, DTU, New Delhi<br>
            Prof. S. Indu, DTU, New Delhi<br>
            Prof. Ashwani Kumar, IGDTUW, New Delhi<br>
            Prof. Uma Nangia, DTU, New Delhi<br>
            Prof. M. T. Beg, JMI, New Delhi<br>
            Prof. Z. A Jaffery, JMI, New Delhi<br>
            Prof. Rajesh Kumar, MNIT Jaipur<br>
            Prof. Jaison Mathew, GEC, Thrissur, Kerala<br>
            Prof. Lillie Dewan, NIT, Kurukshetra<br>
            Prof. Vijyant Agarwal, NSUT, New Delhi<br>
            Prof. Rashmi Gupta, AIACTR, New Delhi<br>
            Prof. J. Panda, DTU, New Delhi<br>
            Prof. R. S Gupta, MAIT, New Delhi<br>
            Prof. N. S Raghav, DTU, New Delhi<br>
            Prof. B. K Kanojia, DTU, New Delhi<br>
            Prof. Arti M. K. AIACTR, New Delhi<br>
            Prof. Bharat Bhushan, DTU, New Delhi<br>
            Prof. Dinesh Chutani, DTU, New Delhi<br>
            Prof. M.M.Tripathi, DTU, New Delhi<br>
            Dr. Bharat Singh Rajpurohit- IIT Mandi<br>
            Dr. Sudharshan Kaarthik R, IIST Thiruvananthapuram<br>
            Dr. Ashish Mathur, IIT Jodhpur<br>
            Dr. Prerana Mukherjee, IIIT Andhra Pradesh<br>
            Dr. Ankit Garg, JIIT, Greater Noida<br>
            Dr. Arun Kumar, MNIT, Jaipur<br>
            Dr. Pankaj Gupta, IGDTUW, New Delhi<br>
            Mr. Kanchan Sharma, IGDTUW, New Delhi<br>
            Dr. Richa Sharma, IITD, New Delhi<br>
            Dr. Tarun Kumar Rawat, NSUT, New Delhi<br>
            Dr. Anil Kumar Yadav, NIT Hamirpur, New Delhi<br>
            Dr. Arun Sharma, IGDTUW, New Delhi<br>
            Dr. Nikhil Sharma, LMNIT, Jaipur<br>
            Dr. Jagdish Chand Bansal, SAU, New Delhi<br>
            Dr. Shwetha M, Presidency University, Bangalore<br>
            Dr. Ravinder M.,IGDTUW, New Delhi<br>
            Dr. Arvinder Kaur, GGSIPU, Delhi<br>
            Dr. Sonam Rewari, DTU, New Delhi<br>
            Mr. S. K Kundu, MAIT, New Delhi<br>
            Dr. Navneet Yadav, MAIT, New Delhi<br>
            Dr. Awadesh Singh, MAIT, New Delhi<br>
            Mr. Rohit Rana, MAIT, New Delhi<br>
            More members are to be added<br>
        </h6>
        
        <h4 class="w700 mb-1"> Pre Screening Committee</h4>
        <h6>
            Dr. Parveen Sinha, MAIT, New Delhi<br>
            Dr. Nitin Sharma, MAIT, New Delhi<br>
            Dr. Neelu Nagpal, MAIT, New Delhi<br>
            Dr. Divya Goel, MAIT, New Delhi<br>
            Mr. Rohit Rana, MAIT, New Delhi
        </h6>
        
        <h4 class="w700 mb-1"> Publicity Committee</h4>
        <h6>
            Mr. Hemant Tulsani, MAIT, New Delhi<br>
            Mr. Vaibhav Nijhawan, MAIT, New Delhi<br>
            Mr. Rohit Lakhane, MAIT, New Delhi<br>
            Mrs. Rajni, MAIT, New Delhi<br>
            Mr. Ashish Sharma, MAIT, New Delhi<br>
            Mrs. Abhilasha Gokhle, MAIT, New Delhi<br>
            Mrs. Vatsala, MAIT, New Delhi
        </h6>
        <h4 class="w700 mb-1"> Local Arrangement Committee (Hospitality / Accommodation / Transportation etc)</h4>
        <h6>
            Mr. Ajay Garg, MAIT, New Delhi<br>
            Mr. Umesh Chandra Singh, MAIT, New Delhi<br>
            Mr. Parveen Chaudhry, MAIT, New Delhi<br>
            Mr. Sudarshan, MAIT, New Delhi<br>
            Mr. Amit Saxena, MAIT, New Delhi<br>
            Ms. Stuti, MAIT, New Delhi
        </h6>
        
        <h4 class="w700 mb-1"> Publication Committee</h4>
        <h6>
            Prof. Ahteshamul Haque, JMI University, New Delhi<br>
            Dr. Divya Goel, MAIT, New Dehi<br>
            Mr. Rohit Rana, MAIT, New Dehi
        </h6>
        
        <h4 class="w700 mb-1"> MAIT Advisory Committee</h4>
        <h6>
            Prof. S.S. Deswal, Dean, MAIT, New Delhi<br>
            Prof. Rajveer Mittal, HOD, EEE, MAIT, New Delhi<br>
            Prof. Namita Gupta, HOD, CSE, MAIT, New Delhi<br>
            Prof. M. L. Sharma, HOD, IT, MAIT, New Delhi<br>
            Prof. V. N. Mathur, HOD, MAE, MAIT, New Delhi<br>
            Prof. Amit Gupta, HOD, MBA, MAIT, New Delhi<br>
            Prof. Pramod Kumar, EEE, MAIT, New Delhi<br>
            Dr. Vaibhav Jain, HOD, ME, MAIT, New Delhi<br>
            Dr. L. P. Singh, MAIT, New Delhi
        </h6>
      </div>
    </section>
    <section id="registration-fee" class="wow fadeInUp">

      <div class="container  py-5 table-responsive">
        <div class="section-header">
          <h2>Registration Fee(s)</h2>
        </div>
        <table cellspacing="0" class="table table-striped">
        	<tbody>
        		<tr>
        			<td>
        			<p style="text-align:center"><strong>CATEGORY</strong></p>
        			</td>
        			<td colspan="2">
        			<p style="text-align:center"><strong>INR</strong></p>
        			</td>
        			<td colspan="2">
        			<p style="text-align:center"><strong>USD</strong></p>
        			</td>
        		</tr>
        		<tr>
        			<td>
        			<p style="text-align:center"><strong>&nbsp;</strong></p>
        			</td>
        			<td>
        			<p style="text-align:center"><strong>NON-IEEE member</strong></p>
        			</td>
        			<td>
        			<p style="text-align:center"><strong>IEEE member(After discount)</strong></p>
        			</td>
        			<td>
        			<p style="text-align:center"><strong>NON-IEEE member</strong></p>
        			</td>
        			<td>
        			<p style="text-align:center"><strong>IEEE member(After discount)</strong></p>
        			</td>
        		</tr>
        		<tr>
        			<td>
        			<p style="text-align:center"><strong>AUTHOR</strong></p>
        			</td>
        			<td colspan="4">
        			<p>&nbsp;</p>
        			</td>
        		</tr>
        		<tr>
        			<td>
        			<p><strong>PROFESSIONALS/ FACULTY</strong></p>
        			</td>
        			<td>
        			<p style="text-align:center">8500</p>
        			</td>
        			<td>
        			<p style="text-align:center">7500</p>
        			</td>
        			<td>
        			<p style="text-align:center">US$&nbsp;&nbsp;350</p>
        			</td>
        			<td>
        			<p style="text-align:center">US$&nbsp;&nbsp;315</p>
        			</td>
        		</tr>
        		<tr>
        			<td>
        			<p><strong>RESEARCH SCHOLAR</strong></p>
        			</td>
        			<td>
        			<p style="text-align:center">8000</p>
        			</td>
        			<td>
        			<p style="text-align:center">7000</p>
        			</td>
        			<td>
        			<p style="text-align:center">US$&nbsp;&nbsp;250</p>
        			</td>
        			<td>
        			<p style="text-align:center">US$&nbsp;&nbsp;225</p>
        			</td>
        		</tr>
        		<tr>
        			<td>
        			<p style="text-align:center"><strong>CO-AUTHOR&nbsp; (If One author has been registered &amp; other Co-Authors also wants to register)</strong></p>
        			</td>
        			<td colspan="4">
        			<p>&nbsp;</p>
        			</td>
        		</tr>
        		<tr>
        			<td>
        			<p><strong>PROFESSIONALS/FACULTY</strong></p>
        			</td>
        			<td>
        			<p style="text-align:center">7500</p>
        			</td>
        			<td>
        			<p style="text-align:center">6500</p>
        			</td>
        			<td>
        			<p style="text-align:center">US$&nbsp;&nbsp;315</p>
        			</td>
        			<td>
        			<p style="text-align:center">US$&nbsp;&nbsp;290</p>
        			</td>
        		</tr>
        		<tr>
        			<td>
        			<p><strong>RESEARCH SCHOLAR</strong></p>
        			</td>
        			<td>
        			<p style="text-align:center">7000</p>
        			</td>
        			<td>
        			<p style="text-align:center">6000</p>
        			</td>
        			<td>
        			<p style="text-align:center">US$&nbsp;&nbsp;215</p>
        			</td>
        			<td>
        			<p style="text-align:center">US$&nbsp;&nbsp;200</p>
        			</td>
        		</tr>
        		<tr>
        			<td>
        			<p style="text-align:center"><strong>NON-AUTHOR PARTICIPANTS</strong></p>
        			</td>
        			<td colspan="4">
        			<p style="text-align:center">&nbsp;</p>
        			</td>
        		</tr>
        		<tr> 
        			<td>
        			<p><strong>PROFESSIONALS (3 DAYS Registration)</strong></p>
        			</td>
        			<td>
        			<p style="text-align:center">6000</p>
        			</td>
        			<td>
        			<p style="text-align:center">4800</p>
        			</td>
        			<td>
        			<p style="text-align:center">-</p>
        			</td>
        			<td>
        			<p style="text-align:center">-</p>
        			</td>
        		</tr>
        		<tr>
        			<td>
        			<p><strong>PROFESSIONALS (1 DAY Registration)</strong></p>
        			</td>
        			<td>
        			<p style="text-align:center">2500</p>
        			</td>
        			<td>
        			<p style="text-align:center">2000</p>
        			</td>
        			<td>
        			<p style="text-align:center">-</p>
        			</td>
        			<td>
        			<p style="text-align:center">-</p>
        			</td>
        		</tr>
        		<tr>
        			<td>
        			<p><strong>FULL TIME STUDENT (3 DAYS Registration)</strong></p>
        			</td>
        			<td>
        			<p style="text-align:center">2500</p>
        			</td>
        			<td>
        			<p style="text-align:center">2000</p>
        			</td>
        			<td>
        			<p style="text-align:center">-</p>
        			</td>
        			<td>
        			<p style="text-align:center">-</p>
        			</td>
        		</tr>
        		<tr>
        			<td>
        			<p><strong>FULL TIME STUDENT (1 DAY Registration)</strong></p>
        			</td>
        			<td>
        			<p style="text-align:center">1200</p>
        			</td>
        			<td>
        			<p style="text-align:center">900</p>
        			</td>
        			<td>
        			<p style="text-align:center">-</p>
        			</td>
        			<td>
        			<p style="text-align:center">-</p>
        			</td>
        		</tr>
        	</tbody>
        </table>

      </div>
    </section>
    <section id="imp-dates" class="section-with-bg wow fadeInUp">

      <div class="container py-5 table-responsive">
        <div class="section-header">
          <h2>Important Dates</h2>
          <p>Tentative Time Schedule with starting Dates</p>
        </div>
        <table cellspacing="0" style="width:100%" class="table table-striped">
        	<tbody>
        		<tr>
        			<td>
        			<p>Call for Paper Submission</p>
        			</td>
        			<td>
        			<p>15th Feb 2021</p>
        			</td>
        		</tr>
        		<tr>
        			<td>
        			<p>Last date of Paper Submission</p>
        			</td>
        			<td>
        			<p>01st April 2021</p>
        			</td>
        		</tr>
        		<tr>
        			<td>
        			<p>Acceptance Notification</p>
        			</td>
        			<td>
        			<p>30th June 2021</p>
        			</td>
        		</tr>
        		<tr>
        			<td>
        			<p>Final Camera-ready paper</p>
        			</td>
        			<td>
        			<p>01st Aug 2021</p>
        			</td>
        		</tr>
        		<tr>
        			<td>
        			<p>Early Bird Registration (with 10% discount)</p>
        			</td>
        			<td>
        			<p>01st Aug 2021</p>
        			</td>
        		</tr>
        		<tr>
        			<td>
        			<p>Last date of Registration (without 10% discount)</p>
        			</td>
        			<td>
        			<p>15th Sept. 2021</p>
        			</td>
        		</tr>
        	</tbody>
        </table>

      </div>
    </section>
    <!--==========================
      Hotels Section
    ============================--
    <section id="hotels" class="section-with-bg wow fadeInUp">

      <div class="container">
        <div class="section-header">
          <h2>Hotels</h2>
          <p>Her are some nearby hotels</p>
        </div>

        <div class="row">

          <div class="col-lg-4 col-md-6">
            <div class="hotel">
              <div class="hotel-img">
                <img src="img/hotels/1.jpg" alt="Hotel 1" class="img-fluid">
              </div>
              <h3><a href="#">Hotel 1</a></h3>
              <div class="stars">
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
              </div>
              <p>0.4 Mile from the Venue</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6">
            <div class="hotel">
              <div class="hotel-img">
                <img src="img/hotels/2.jpg" alt="Hotel 2" class="img-fluid">
              </div>
              <h3><a href="#">Hotel 2</a></h3>
              <div class="stars">
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star-half-full"></i>
              </div>
              <p>0.5 Mile from the Venue</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6">
            <div class="hotel">
              <div class="hotel-img">
                <img src="img/hotels/3.jpg" alt="Hotel 3" class="img-fluid">
              </div>
              <h3><a href="#">Hotel 3</a></h3>
              <div class="stars">
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
              </div>
              <p>0.6 Mile from the Venue</p>
            </div>
          </div>

        </div>
      </div>

    </section>

    <!--==========================
      Gallery Section
    ============================-->
    <section id="gallery" class="wow fadeInUp">

      <div class="container">
        <div class="section-header">
          <h2>Gallery</h2>
          <!--<p>Check our gallery from the recent events</p>-->
          <p>Will be updated soon.</p>
        </div>
      </div>
      <!--
      <div class="owl-carousel gallery-carousel">
        <a href="img/gallery/1.jpg" class="venobox" data-gall="gallery-carousel"><img src="img/gallery/1.jpg"
            alt=""></a>
        <a href="img/gallery/2.jpg" class="venobox" data-gall="gallery-carousel"><img src="img/gallery/2.jpg"
            alt=""></a>
        <a href="img/gallery/3.jpg" class="venobox" data-gall="gallery-carousel"><img src="img/gallery/3.jpg"
            alt=""></a>
        <a href="img/gallery/4.jpg" class="venobox" data-gall="gallery-carousel"><img src="img/gallery/4.jpg"
            alt=""></a>
        <a href="img/gallery/5.jpg" class="venobox" data-gall="gallery-carousel"><img src="img/gallery/5.jpg"
            alt=""></a>
        <a href="img/gallery/6.jpg" class="venobox" data-gall="gallery-carousel"><img src="img/gallery/6.jpg"
            alt=""></a>
        <a href="img/gallery/7.jpg" class="venobox" data-gall="gallery-carousel"><img src="img/gallery/7.jpg"
            alt=""></a>
        <a href="img/gallery/8.jpg" class="venobox" data-gall="gallery-carousel"><img src="img/gallery/8.jpg"
            alt=""></a>
      </div>
-->
    </section>

    <!--==========================
      Sponsors Section
    ============================-->
    <section id="supporters" class="section-with-bg wow fadeInUp">

      <div class="container">
        <div class="section-header">
          <h2>Sponsors</h2>
        </div>
        <div class="row justify-content-center">

          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="supporter-logo">
              <img src="https://upload.wikimedia.org/wikipedia/en/thumb/b/b8/GGSIU_logo.svg/330px-GGSIU_logo.svg.png" style="max-height:100%" class="img-fluid" alt="">
            </div>
            <h6 class="text-center"><strong>Guru Gobind Singh Indraprastha University<strong></h6>
          </div>

        </div>
<!--
        <div class="row no-gutters supporters-wrap clearfix">

          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="supporter-logo">
              <img src="img/supporters/1.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="supporter-logo">
              <img src="img/supporters/2.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="supporter-logo">
              <img src="img/supporters/3.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="supporter-logo">
              <img src="img/supporters/4.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="supporter-logo">
              <img src="img/supporters/5.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="supporter-logo">
              <img src="img/supporters/6.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="supporter-logo">
              <img src="img/supporters/7.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-xs-6">
            <div class="supporter-logo">
              <img src="img/supporters/8.png" class="img-fluid" alt="">
            </div>
          </div>

        </div>
-->
      </div>

    </section>

    <!--==========================
      F.A.Q Section
    ============================--
    <section id="faq" class="wow fadeInUp">

      <div class="container">

        <div class="section-header">
          <h2>F.A.Q </h2>
          <p>Will be updated soon.</p>
        </div>

        <div class="row justify-content-center">
          <div class="col-lg-9">
            <ul id="faq-list">

              <li>
                <a data-toggle="collapse" class="collapsed" href="#faq1">Non consectetur a erat nam at lectus urna duis?
                  <i class="fa fa-minus-circle"></i></a>
                <div id="faq1" class="collapse" data-parent="#faq-list">
                  <p>
                    Feugiat pretium nibh ipsum consequat. Tempus iaculis urna id volutpat lacus laoreet non curabitur
                    gravida. Venenatis lectus magna fringilla urna porttitor rhoncus dolor purus non.
                  </p>
                </div>
              </li>

              <li>
                <a data-toggle="collapse" href="#faq2" class="collapsed">Feugiat scelerisque varius morbi enim nunc
                  faucibus a pellentesque? <i class="fa fa-minus-circle"></i></a>
                <div id="faq2" class="collapse" data-parent="#faq-list">
                  <p>
                    Dolor sit amet consectetur adipiscing elit pellentesque habitant morbi. Id interdum velit laoreet id
                    donec ultrices. Fringilla phasellus faucibus scelerisque eleifend donec pretium. Est pellentesque
                    elit ullamcorper dignissim. Mauris ultrices eros in cursus turpis massa tincidunt dui.
                  </p>
                </div>
              </li>

              <li>
                <a data-toggle="collapse" href="#faq3" class="collapsed">Dolor sit amet consectetur adipiscing elit
                  pellentesque habitant morbi? <i class="fa fa-minus-circle"></i></a>
                <div id="faq3" class="collapse" data-parent="#faq-list">
                  <p>
                    Eleifend mi in nulla posuere sollicitudin aliquam ultrices sagittis orci. Faucibus pulvinar
                    elementum integer enim. Sem nulla pharetra diam sit amet nisl suscipit. Rutrum tellus pellentesque
                    eu tincidunt. Lectus urna duis convallis convallis tellus. Urna molestie at elementum eu facilisis
                    sed odio morbi quis
                  </p>
                </div>
              </li>

              <li>
                <a data-toggle="collapse" href="#faq4" class="collapsed">Ac odio tempor orci dapibus. Aliquam eleifend
                  mi in nulla? <i class="fa fa-minus-circle"></i></a>
                <div id="faq4" class="collapse" data-parent="#faq-list">
                  <p>
                    Dolor sit amet consectetur adipiscing elit pellentesque habitant morbi. Id interdum velit laoreet id
                    donec ultrices. Fringilla phasellus faucibus scelerisque eleifend donec pretium. Est pellentesque
                    elit ullamcorper dignissim. Mauris ultrices eros in cursus turpis massa tincidunt dui.
                  </p>
                </div>
              </li>

              <li>
                <a data-toggle="collapse" href="#faq5" class="collapsed">Tempus quam pellentesque nec nam aliquam sem et
                  tortor consequat? <i class="fa fa-minus-circle"></i></a>
                <div id="faq5" class="collapse" data-parent="#faq-list">
                  <p>
                    Molestie a iaculis at erat pellentesque adipiscing commodo. Dignissim suspendisse in est ante in.
                    Nunc vel risus commodo viverra maecenas accumsan. Sit amet nisl suscipit adipiscing bibendum est.
                    Purus gravida quis blandit turpis cursus in
                  </p>
                </div>
              </li>

              <li>
                <a data-toggle="collapse" href="#faq6" class="collapsed">Tortor vitae purus faucibus ornare. Varius vel
                  pharetra vel turpis nunc eget lorem dolor? <i class="fa fa-minus-circle"></i></a>
                <div id="faq6" class="collapse" data-parent="#faq-list">
                  <p>
                    Laoreet sit amet cursus sit amet dictum sit amet justo. Mauris vitae ultricies leo integer malesuada
                    nunc vel. Tincidunt eget nullam non nisi est sit amet. Turpis nunc eget lorem dolor sed. Ut
                    venenatis tellus in metus vulputate eu scelerisque. Pellentesque diam volutpat commodo sed egestas
                    egestas fringilla phasellus faucibus. Nibh tellus molestie nunc non blandit massa enim nec.
                  </p>
                </div>
              </li>

            </ul>
          </div>
        </div>

      </div>

    </section>

    <!--==========================
      Subscribe Section
    ============================--
    <section id="subscribe">
      <div class="container wow fadeInUp">
        <div class="section-header">
          <h2>Newsletter</h2>
          <p>Rerum numquam illum recusandae quia mollitia consequatur.</p>
        </div>

        <form method="POST" action="#">
          <div class="form-row justify-content-center">
            <div class="col-auto">
              <input type="text" class="form-control" placeholder="Enter your Email">
            </div>
            <div class="col-auto">
              <button type="submit">Subscribe</button>
            </div>
          </div>
        </form>

      </div>
    </section>

    <!--==========================
      Buy Ticket Section
    ============================--
    <section id="buy-tickets" class="section-with-bg wow fadeInUp">
      <div class="container">

        <div class="section-header">
          <h2>Buy Tickets</h2>
          <p>Velit consequatur consequatur inventore iste fugit unde omnis eum aut.</p>
        </div>

        <div class="row">
          <div class="col-lg-4">
            <div class="card mb-5 mb-lg-0">
              <div class="card-body">
                <h5 class="card-title text-muted text-uppercase text-center">Standard Access</h5>
                <h6 class="card-price text-center">$150</h6>
                <hr>
                <ul class="fa-ul">
                  <li><span class="fa-li"><i class="fa fa-check"></i></span>Regular Seating</li>
                  <li><span class="fa-li"><i class="fa fa-check"></i></span>Coffee Break</li>
                  <li><span class="fa-li"><i class="fa fa-check"></i></span>Custom Badge</li>
                  <li class="text-muted"><span class="fa-li"><i class="fa fa-times"></i></span>Community Access</li>
                  <li class="text-muted"><span class="fa-li"><i class="fa fa-times"></i></span>Workshop Access</li>
                  <li class="text-muted"><span class="fa-li"><i class="fa fa-times"></i></span>After Party</li>
                </ul>
                <hr>
                <div class="text-center">
                  <button type="button" class="btn" data-toggle="modal" data-target="#buy-ticket-modal"
                    data-ticket-type="standard-access">Buy Now</button>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="card mb-5 mb-lg-0">
              <div class="card-body">
                <h5 class="card-title text-muted text-uppercase text-center">Pro Access</h5>
                <h6 class="card-price text-center">$250</h6>
                <hr>
                <ul class="fa-ul">
                  <li><span class="fa-li"><i class="fa fa-check"></i></span>Regular Seating</li>
                  <li><span class="fa-li"><i class="fa fa-check"></i></span>Coffee Break</li>
                  <li><span class="fa-li"><i class="fa fa-check"></i></span>Custom Badge</li>
                  <li><span class="fa-li"><i class="fa fa-check"></i></span>Community Access</li>
                  <li class="text-muted"><span class="fa-li"><i class="fa fa-times"></i></span>Workshop Access</li>
                  <li class="text-muted"><span class="fa-li"><i class="fa fa-times"></i></span>After Party</li>
                </ul>
                <hr>
                <div class="text-center">
                  <button type="button" class="btn" data-toggle="modal" data-target="#buy-ticket-modal"
                    data-ticket-type="pro-access">Buy Now</button>
                </div>
              </div>
            </div>
          </div>
          
          <div class="col-lg-4">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title text-muted text-uppercase text-center">Premium Access</h5>
                <h6 class="card-price text-center">$350</h6>
                <hr>
                <ul class="fa-ul">
                  <li><span class="fa-li"><i class="fa fa-check"></i></span>Regular Seating</li>
                  <li><span class="fa-li"><i class="fa fa-check"></i></span>Coffee Break</li>
                  <li><span class="fa-li"><i class="fa fa-check"></i></span>Custom Badge</li>
                  <li><span class="fa-li"><i class="fa fa-check"></i></span>Community Access</li>
                  <li><span class="fa-li"><i class="fa fa-check"></i></span>Workshop Access</li>
                  <li><span class="fa-li"><i class="fa fa-check"></i></span>After Party</li>
                </ul>
                <hr>
                <div class="text-center">
                  <button type="button" class="btn" data-toggle="modal" data-target="#buy-ticket-modal"
                    data-ticket-type="premium-access">Buy Now</button>
                </div>

              </div>
            </div>
          </div>
        </div>

      </div>

      <!-- Modal Order Form --
      <div id="buy-ticket-modal" class="modal fade">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Buy Tickets</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <form method="POST" action="#">
                <div class="form-group">
                  <input type="text" class="form-control" name="your-name" placeholder="Your Name">
                </div>
                <div class="form-group">
                  <input type="text" class="form-control" name="your-email" placeholder="Your Email">
                </div>
                <div class="form-group">
                  <select id="ticket-type" name="ticket-type" class="form-control">
                    <option value="">-- Select Your Ticket Type --</option>
                    <option value="standard-access">Standard Access</option>
                    <option value="pro-access">Pro Access</option>
                    <option value="premium-access">Premium Access</option>
                  </select>
                </div>
                <div class="text-center">
                  <button type="submit" class="btn">Buy Now</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

    </section>

    <!--==========================
      Contact Section
    ============================--
    <section id="contact" class="section-bg wow fadeInUp">

      <div class="container">

        <div class="section-header">
          <h2>Contact Us</h2>
          <p>Nihil officia ut sint molestiae tenetur.</p>
        </div>

        <div class="row contact-info">

          <div class="col-md-4">
            <div class="contact-address">
              <i class="ion-ios-location-outline"></i>
              <h3>Address</h3>
              <address>A108 Adam Street, NY 535022, USA</address>
            </div>
          </div>

          <div class="col-md-4">
            <div class="contact-phone">
              <i class="ion-ios-telephone-outline"></i>
              <h3>Phone Number</h3>
              <p><a href="tel:+155895548855">+1 5589 55488 55</a></p>
            </div>
          </div>

          <div class="col-md-4">
            <div class="contact-email">
              <i class="ion-ios-email-outline"></i>
              <h3>Email</h3>
              <p><a href="mailto:info@example.com">info@example.com</a></p>
            </div>
          </div>

        </div>

        <div class="form">
          <div id="sendmessage">Your message has been sent. Thank you!</div>
          <div id="errormessage"></div>
          <form action="" method="post" role="form" class="contactForm">
            <div class="form-row">
              <div class="form-group col-md-6">
                <input type="text" name="name" class="form-control" id="name" placeholder="Your Name"
                  data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                <div class="validation"></div>
              </div>
              <div class="form-group col-md-6">
                <input type="email" class="form-control" name="email" id="email" placeholder="Your Email"
                  data-rule="email" data-msg="Please enter a valid email" />
                <div class="validation"></div>
              </div>
            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject"
                data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
              <div class="validation"></div>
            </div>
            <div class="form-group">
              <textarea class="form-control" name="message" rows="5" data-rule="required"
                data-msg="Please write something for us" placeholder="Message"></textarea>
              <div class="validation"></div>
            </div>
            <div class="text-center"><button type="submit">Send Message</button></div>
          </form>
        </div>

      </div>
    </section>

  </main>


  <!--==========================
    Footer
  ============================-->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-5 col-md-6 footer-info">
            <h1 class="mb-0"><a href="#main"><span class="text-white">IC</span>IERA <span class="text-white">20</span>21</a></h1>
            <p>Organized By</p>
            <p><strong>Department of Electronics and Communication Engineering</strong></p>
            <p class="mt-2"><strong>Thursday to Saturday, 07th-09th October 2021</strong></p>
          </div>

          <!--<div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="fa fa-angle-right"></i> <a href="#">Home</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">About us</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">Services</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="fa fa-angle-right"></i> <a href="#">Home</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">About us</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">Services</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>-->
          <div class="col-lg-2 col-md-6 footer-links">
          </div>
          <div class="col-lg-5 col-md-6 footer-contact">
            <h4>Contact Us</h4>
            <p>
              Maharaja Agrasen Institute Of Technology<br>
              Rohini, Sector-22, <br>
              New Delhi-110086, India<br>
              <!--<strong>Phone:</strong> <br>-->
            </p>
            <a href="mailto:iciera@mait.ac.in"><strong>iciera@mait.ac.in</strong></a>

            <!--<div class="social-links">
              <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
              <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
              <a href="#" class="instagram"><i class="fa fa-instagram"></i></a>
              <a href="#" class="google-plus"><i class="fa fa-google-plus"></i></a>
              <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
            </div>-->

          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong>ICIERA</strong> 2020. All Rights Reserved
      </div>
    </div>
  </footer><!-- #footer -->

  <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/venobox/venobox.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>
</body>

</html>