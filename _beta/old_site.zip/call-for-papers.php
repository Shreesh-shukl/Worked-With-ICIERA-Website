<!DOCTYPE html>
<html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  
  <title>ICIERA 21 - International Conference on Industrial Electronics Research and Applications, 2021</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="https://ece.mait.ac.in/templates/purity_iii/favicon.ico" rel="icon">
  <!--<link href="img/apple-touch-icon.png" rel="apple-touch-icon">-->

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800"
    rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/venobox/venobox.css" rel="stylesheet">
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">
  <style>
          .w700{
              font-weight:700;
          }
          table p{
              margin-bottom:0px !important;
          }
        .blinker{
           animation-duration: 1000ms;
           animation-name: blink;
           animation-iteration-count: infinite;
           animation-direction: alternate;
        }
        @keyframes blink {
           0% {
              color:#fff;
           }
           50% {
              color:#ff0;
           }
           100% {
              color:#f80;
           }
         }
      </style>
</head>

<body>

  <!--==========================
    Header
  ============================-->
  <header id="header">
    <div class="container">

      <div id="logo" class="pull-left">
        <!-- Uncomment below if you prefer to use a text logo -->
        <h1><a href="#main">IC<span>IERA</span> 20<span>21</span></a></h1>
        <!--<a href="#intro" class="scrollto"><img src="img/logo.png" alt="" title=""></a>-->
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="menu-active"><a href="index.php">Home</a></li>
          <li><a href="call-for-papers.php">Call For Papers</a></li>
          <li><a href="index.php#about">About</a></li>
          <!--<li><a href="#speakers">Speakers</a></li>-->
          <li><a href="index.php#tracks">Tracks</a></li>
          <li><a href="index.php#schedule">Schedule</a></li>
          <li><a href="index.php#venue">Venue</a></li>
          <!--<li><a href="#hotels">Hotels</a></li>
          <li><a href="#gallery">Gallery</a></li>-->
          <li><a href="index.php#supporters">Sponsors</a></li>
          <!--<li><a href="#contact">Contact</a></li>
          <li class="buy-tickets"><a href="#buy-tickets">Buy Tickets</a></li>-->
        </ul>
      </nav><!-- #nav-menu-container -->
    </div>
  </header><!-- #header -->

  <!--==========================
    Intro Section
  ============================-->
  <section id="intro">
    <div class="intro-container  fadeIn">
        <marquee><a href="https://easychair.org/conferences/?conf=iciera2021" target="_blank" style="font-size:25px"><span class="blinker">Paper submission is open now. Click here to submit paper.</span></a></marquee>
      <h1 class="mb-4 pb-0">International Conference on <br><span>Industrial Electronics <br>Research and Applications</span></h1>
      <p class="mb-2 pb-0">Organized By</p>
      <h3 class="mb-2 pb-0 text-theme">Department of Electronics and Communication Engineering</h3>
      <p class="mb-2 pb-0">Maharaja Agrasen Institute Of Technology</p>
      <p class="mb-2 pb-0">Rohini, Sec-22, New Delhi-110086, India</p>
      <!--<a href="https://www.youtube.com/watch?v=jDDaplaOz7Q" class="venobox play-btn mb-4" data-vbtype="video" data-autoplay="true"></a>-->
      <p class="mb-2 pb-0">Thursday to Saturday, 07th-09th October 2021</p>
      <a href="https://ece.mait.ac.in/iciera21/#about" class="about-btn scrollto">About The Event</a>
    </div>
  </section>

  <main id="main">

    <section class="py-5">
        <div class="container">
            <div class="section-header">
                <h2>Call For Papers</h2>
            </div>
            <div class="row justify-content-center">
                <div class="col-12 col-lg-10 text-justify">
                    For submission of papers, click here to go to the <a class="btn btn-sm btn-primary" target="_blank" href="https://easychair.org/conferences/?conf=iciera2021">EasyChair</a> submission page.
                    <br><br>
                    Kindly submit your manuscripts in IEEE Format. Refer the following link to download the requisite MS WORD/Latex templates.<br><a class="btn btn-sm btn-primary" target="_blank" href="https://www.ieee.org/conferences/publishing/templates.html">IEEE Manuscript Templates for Conference Proceedings</a>
                    
                    <br><br>
                    The paper size is limited to max. 6 pages.
                </div>
            </div>
        </div>
    </section>
    <section class="py-5">
        <div class="container">
            <div class="section-header">
                <h2>Plagiarism Policy</h2>
            </div>
            <div class="row justify-content-center">
                <div class="col-12 col-lg-10 text-justify">
                    All the submitted manuscripts/papers will be subjected to "Similarity (Plagiarism) Test" by plagiarism checker tools provided by IEEE crosscheck and those that are deemed unacceptable will be rejected without a formal review.<br>Plagiarism should be less than 20%.
                </div>
            </div>
        </div>
    </section>
    
    <!--==========================
      Tracks Section
    ============================-->
   


    <section id="imp-dates" class="section-with-bg  fadeInUp">

      <div class="container py-5 table-responsive">
        <div class="section-header">
          <h2>Important Dates</h2>
          <p>Tentative Time Schedule with starting Dates</p>
        </div>
        <table cellspacing="0" style="width:100%" class="table table-striped">
        	<tbody>
        		<tr>
        			<td>
        			<p>Call for Paper Submission</p>
        			</td>
        			<td>
        			<p>15th Feb 2021</p>
        			</td>
        		</tr>
        		<tr>
        			<td>
        			<p>Last date of Paper Submission</p>
        			</td>
        			<td>
        			<p>15th Jul 2021</p>
        			</td>
        		</tr>
        		<tr>
        			<td>
        			<p>Acceptance Notification</p>
        			</td>
        			<td>
        			<p>30th Aug 2021</p>
        			</td>
        		</tr>
        		<tr>
        			<td>
        			<p>Final Camera-ready paper</p>
        			</td>
        			<td>
        			<p>01st Oct 2021</p>
        			</td>
        		</tr>
        		<tr>
        			<td>
        			<p>Early Bird Registration (with 10% discount)</p>
        			</td>
        			<td>
        			<p>10th Oct 2021</p>
        			</td>
        		</tr>
        		<tr>
        			<td>
        			<p>Last date of Registration (without 10% discount)</p>
        			</td>
        			<td>
        			<p>15th Nov 2021</p>
        			</td>
        		</tr>
        	</tbody>
        </table>

      </div>
    </section>
   

    

  <!--==========================
    Footer
  ============================-->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-5 col-md-6 footer-info">
            <h1 class="mb-0"><a href="#main"><span class="text-white">IC</span>IERA <span class="text-white">20</span>21</a></h1>
            <p>Organized By</p>
            <p><strong>Department of Electronics and Communication Engineering</strong></p>
            <p class="mt-2"><strong>Thursday to Saturday, 07th-09th October 2021</strong></p>
          </div>

          <!--<div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="fa fa-angle-right"></i> <a href="#">Home</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">About us</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">Services</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="fa fa-angle-right"></i> <a href="#">Home</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">About us</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">Services</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>-->
          <div class="col-lg-2 col-md-6 footer-links">
          </div>
          <div class="col-lg-5 col-md-6 footer-contact">
            <h4>Contact Us</h4>
            <p>
              Maharaja Agrasen Institute Of Technology<br>
              Rohini, Sector-22, <br>
              New Delhi-110086, India<br>
              <!--<strong>Phone:</strong> <br>-->
            </p>
            <a href="mailto:iciera@mait.ac.in"><strong>iciera@mait.ac.in</strong></a>

            <!--<div class="social-links">
              <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
              <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
              <a href="#" class="instagram"><i class="fa fa-instagram"></i></a>
              <a href="#" class="google-plus"><i class="fa fa-google-plus"></i></a>
              <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
            </div>-->

          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong>ICIERA</strong> 2020. All Rights Reserved
      </div>
    </div>
  </footer><!-- #footer -->

  <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib//.min.js"></script>
  <script src="lib/venobox/venobox.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>
</body>

</html>