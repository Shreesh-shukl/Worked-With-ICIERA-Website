		<!-- footer 
			================================================== -->
            <footer class="third-style">
			<div class="container">

				<p class="copyright-line">&copy; Copyright ICIERS 2021 | All rights reserved</p>

			</div>
		</footer>
		<!-- End footer -->

	</div>
	<!-- End Container -->
    <div class="preloader">
		<img alt="" src="images/loader.gif">
	</div>

	<script src="<?=base_url('assets')?>/js/eventium-plugins.min.js"></script>
	<script src="<?=base_url('assets')?>/js/countdown.js"></script>
	<script src="<?=base_url('assets')?>/js/jquery.countTo.js"></script>
	<script src="<?=base_url('assets')?>/js/popper.js"></script>
	<script src="<?=base_url('assets')?>/js/bootstrap.min.js"></script>
    <!--<script src="http://maps.google.com/maps/api/js?key=AIzaSyCiqrIen8rWQrvJsu-7f4rOta0fmI5r2SI&amp;sensor=false&amp;language=en"></script>
	<script src="<?=base_url('assets')?>/js/gmap3.min.js"></script>-->
	<script src="<?=base_url('assets')?>/js/script.js"></script>
	
</body>
</html>