<!doctype html>


<html lang="en" class="no-js">

<!-- Mirrored from nunforest.com/eventium/home2.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 01 Apr 2021 06:50:20 GMT -->
<head>
	<title>ICIERA 2021</title>

	<meta charset="utf-8">

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	
	<link rel="stylesheet" href="<?=base_url('assets/css/eventium-assets.min.css')?>">
	<link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/style.css')?>">
	<style>
		@keyframes blink {
           0% {
              color:#fff;
           }
           50% {
              color:#ff0;
           }
           100% {
              color:#5ff;
           }
         }
		.blinker {
			animation-duration: 1000ms;
			animation-name: blink;
			animation-iteration-count: infinite;
			animation-direction: alternate;
		}
	</style>

</head>
<body>