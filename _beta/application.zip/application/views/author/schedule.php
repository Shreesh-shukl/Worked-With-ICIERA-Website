    <div id="container">
        <?php include("./application/views/includes/navigation.php"); ?>
        <section class="py-5">
            <div class="container">
                <div class="row">
                    <div class="col text-justify">
                        <div class="title-section">
                            <h1>Detailed Schedule</h1>
                        </div>
                        <p>To be updated soon.</p>
                    </div>
                </div>
            </div>
        </section>