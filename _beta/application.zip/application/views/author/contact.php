    <div id="container">
        <?php include("./application/views/includes/navigation.php"); ?>
        <section class="contact-section3 mb-0 pb-0">
			<div class="container">
				<div class="title-section">
					<h1>Contact Us</h1>
				</div>
				<div class="contact-box">
					<div class="contact-info">
						<div class="row justify-content-center">
							<div class="col-md-4">
								<p><i class="ionicons ion-ios-location-outline"></i>Maharaja Agrasen Institute of Technology<br> New Delhi 110086</p>
							</div>
							<div class="col-md-4 d-none">
								<p><i class="ionicons ion-ios-telephone-outline"></i>1-800-123-1234</p>
							</div>
							<div class="col-md-4">
								<p><i class="ionicons ion-ios-email-outline"></i>iciera2021@gmail.com</p>
							</div>
						</div>
					</div>
				</div>
			</div>
        </section>
        <div class="mapouter" style="width:100%"><div class="gmap_canvas" style="width:100%"><iframe width="100%" height="500" id="gmap_canvas" src="https://maps.google.com/maps?q=maharaja%20agrasen%20institute%20of%20technology%20delhi&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://123movies-to.org"></a><br><style>.mapouter{position:relative;text-align:right;height:500px;width:100px;}</style><style>.gmap_canvas {overflow:hidden;background:none!important;height:500px;width:100px;}</style></div></div>